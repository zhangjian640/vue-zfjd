<template>
  <div class="ratingselect">
    <div class="rating-type">
      <span @click="select(2, $event)" class="block positive" :class="{'active': selectType===2}">{{desc.all}}<span class="count">{{ratings.length}}</span></span>
      <span @click="select(0, $event)" class="block positive" :class="{'active': selectType===0}">{{desc.positive}}<span class="count">{{positives.length}}</span></span>
      <span @click="select(1, $event)" class="block negative" :class="{'active': selectType===1}">{{desc.negative}}<span class="count">{{negatives.length}}</span></span>
    </div>
  </div>
</template>
<script>
  const POSITIVE = 0
  const NEGATIVE = 1
  const ALL = 2
  export default {
    props: {
      ratings: {
        type: Array,
        default () {
          return []
        }
      },
      desc: {
        type: Object,
        default () {
          return {
            all: '全部',
            positive: '未读',
            negative: '已读'
          }
        }
      }
    },
    data () {
      return {
        selectType: ALL,
        onlyContent: false
      }
    },
    computed: {
      // 过滤 未读的个数
      positives () {
        return this.ratings.filter((rating) => {
          return rating.rateType === POSITIVE
        })
      },
      // 过滤 已读的个数
      negatives () {
        return this.ratings.filter((rating) => {
          return rating.rateType === NEGATIVE
        })
      }
    },
    methods: {
      select (type, event) {
        if (!event._constructed) {
          return
        }
        this.selectType = type
        this.$emit('select-type', type)
      }
    }
  }
</script>
<style lang="less">
  .ratingselect{
    .rating-type{
      padding: 18px 0;
      margin:0 18px;
      font-size: 0;
      .block{
        display: inline-block;
        font-size: 12px;
        padding: 8px 12px;
        margin-right: 8px;
        border-radius: 1px;
        color: rgb(77, 85, 93);
        &:active{
          color: #fff;
        }
        .count{
          margin-left: 2px;
          font-size: 8px;
          &:active {
            background: rgb(0, 160, 220);
          }
        }
          &:active{
          background: rgb(77, 85, 93);
        }
      }
    }
  }
</style>
