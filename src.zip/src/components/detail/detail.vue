<template>
  <div class="detail">
    <div class="header-wrap">
      <div class="back" @click="goBack">
      </div>
      <div class="title-msg">武汉公安移动警务应用平台</div>
    </div>
    <div class="message-title">消息内容</div>
    <p class="message">您办理的案件(20170717郑作法被诈骗案：J4201146200002017070026)即将在(2017-07-25)日超期，请抓紧时间处理。</p>
    <table>
      <tr>
        <td width="30%">警情编号</td>
        <td width="70%">J4201146200002017070026</td>
      </tr>
      <tr>
        <td>警情名词</td>
        <td>盘龙城经济开发区电动车被盗案</td>
      </tr>
      <tr>
        <td>主办单位</td>
        <td>盘龙城经济开发区派出所</td>
      </tr>
      <tr>
        <td>主办人</td>
        <td>陈浩</td>
      </tr>
      <tr>
        <td>到期时间</td>
        <td>2017-07-25 11:09:48</td>
      </tr>
      <tr>
        <td>受案时间</td>
        <td>2017-07-20 11:29:00</td>
      </tr>
    </table>
    <div class="case-title">简要警情</div>
    <div class="case-detail">
      检察机关在审查起诉阶段，依法告知了被告人享有的诉讼权利，依法讯问了被告人，并听取了其辩护人的意见。武汉市人民检察院起诉书指控：自2014年下半年至2016年1月，被告人刘佳采取虚构事实的方式，诱骗众多购房者出资购买武汉某高档楼盘，骗取购房款共计人民币4.5亿余元，期间，为取得房地产公司销售人员王勇的帮助，刘佳多次给予王勇财物共计145万余元。
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    data () {
      return {}
    },
    methods: {
      goBack () {
        this.$router.back()
      }
    }
  }
</script>

<style scoped lang="less" rel="stylesheet/less">
  .detail {
    .header-wrap {
      background: #000;
      height: 1.3rem;
      position: relative;
      .back {
        width: .3rem;
        height: .5rem;
        top: 50%;
        margin-top: -.25rem;
        position: absolute;
        left: .55rem;
        z-index: 10;
        background: url(./back.png);
        background-size: 100%;
      }
      .title-msg {
        width: 100%;
        position: absolute;
        height: 1.3rem;
        line-height: 1.3rem;
        color: #fff;
        font-size: .48rem;
        text-align: center;
        box-sizing: border-box;
      }
    }
    .message-title {
      height: 1.26rem;
      background: linear-gradient(#2ca2f7, #1a92eb);
      color: #fff;
      text-align: center;
      font-size: .6rem;
      line-height: 1.26rem;
    }
    .message {
      padding: .5rem;
      color: #000;
      font-size: .5rem;
      line-height: 1.5;
    }
    table {
      width: 100%;
      margin-top: .3rem;
      tr {
        td {
          line-height: 1.12rem;
          border-top: 1px solid #f3f3f4;
          color: #222c3c;
          padding-left: .5rem;
          font-size: 14px;
          background: #fff;
          box-sizing: border-box;
          &:first-child {
            background: #fcfcfc;
            color: #9299a7;
            border-right: 1px solid #f3f3f4;
          }
        }
        &:last-child {
          border-bottom: 1px solid #f3f3f4;
        }
      }
    }
    .case-title {
      height: 1.24rem;
      line-height: 1.24rem;
      color: #999;
      font-size: .6rem;
      text-align: center;
      border-bottom: 1px solid #f3f3f4;
    }
    .case-detail{
      padding: .5rem;
      font-size: 18px;
      line-height: 1.5;
    }
  }
</style>
