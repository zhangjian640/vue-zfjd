// import Welcome from '@/components/welcome/welcome'
// import Login from '@/components/login/login'
import List from '@/components/list/list'
import Detail from '@/components/detail/detail'
import Index from '@/components/index/index'

export default [
  {
    path: '/',
    name: 'Index',
    component: Index
  },
  {
    path: '/list',
    name: 'List',
    component: List
  },
  {
    path: '/detail',
    name: 'Detail',
    component: Detail
  }
]
